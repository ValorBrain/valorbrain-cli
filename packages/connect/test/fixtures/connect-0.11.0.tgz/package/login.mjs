/**
 * Browser login for @valorbrain/connect: no token to copy by hand.
 *
 * RFC 8628 device flow served by the ValorBrain app. The CLI asks the app for
 * a code naming the harnesses it found, opens the approval page
 * (/cli/link?code=…) and polls until the person approves this computer there.
 * The approval creates one MCP token per harness (attributed to that harness,
 * revocable on its own in Settings → MCP Tokens) and the app hands them over
 * exactly once. A person without an account creates it on the way: the
 * approval page sends them through sign-up and back.
 *
 * Two URLs cross from the app into this machine, and neither is trusted as
 * is: the approval URL is opened only when it is an https page of the app
 * itself (http only on loopback), and the engine URL the tokens belong to is
 * accepted under the same rule.
 *
 * Node built-ins only; everything that touches the network or spawns a
 * process can be injected, so the tests run offline.
 */

import { spawn } from "node:child_process";
import { randomBytes } from "node:crypto";
import { chmodSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { hostname, platform as osPlatform } from "node:os";
import { join } from "node:path";

export const DEFAULT_APP = "https://valorbrain.valor.digital";

const OS_NAMES = { win32: "Windows", darwin: "macOS", linux: "Linux" };
const REQUEST_TIMEOUT_MS = 10_000;

export function resolveAppUrl({ flag = null, env = process.env } = {}) {
  const norm = (u) => String(u).trim().replace(/\/+$/, "");
  if (flag) return norm(flag);
  if (env.VALORBRAIN_APP_URL) return norm(env.VALORBRAIN_APP_URL);
  return DEFAULT_APP;
}

function safeHostname() {
  try {
    return hostname() || "computer";
  } catch {
    return "computer";
  }
}

/**
 * A random id for this installation (~/.valorbrain/install-id), created on
 * first use. The app puts its first characters in the token names, so two
 * computers with the same hostname never replace each other's tokens when one
 * of them re-authorizes. Not a secret; never derived from the machine.
 */
export function installId(home) {
  const dir = join(home, ".valorbrain");
  const file = join(dir, "install-id");
  try {
    const saved = readFileSync(file, "utf-8").trim().toLowerCase();
    if (/^[a-z0-9]{8,32}$/.test(saved)) return saved;
  } catch {
    /* first run */
  }
  const fresh = randomBytes(8).toString("hex");
  try {
    mkdirSync(dir, { recursive: true, mode: 0o700 });
    writeFileSync(file, `${fresh}\n`, { mode: 0o600 });
    try { chmodSync(file, 0o600); } catch { /* not supported on this fs */ }
  } catch {
    /* unwritable home: the id still works for this run */
  }
  return fresh;
}

/** "DESKTOP-7 (Windows)" — how this computer shows on the approval page and in token names. */
export function deviceLabel({ host = safeHostname(), platform = osPlatform() } = {}) {
  return `${host} (${OS_NAMES[platform] ?? platform})`.slice(0, 80);
}

function isLoopback(hostnameValue) {
  return hostnameValue === "localhost" || hostnameValue === "127.0.0.1" || hostnameValue === "[::1]" || hostnameValue === "::1";
}

/** https, or http on a loopback host (local development). */
function isAcceptableOrigin(url) {
  return url.protocol === "https:" || (url.protocol === "http:" && isLoopback(url.hostname));
}

/**
 * The approval page URL, resolved against the app and kept only when it is
 * a page of that same app over an acceptable scheme. Anything else (another
 * host, `file:`, a custom scheme) is never handed to the OS opener.
 */
export function approvalUrl(raw, app) {
  try {
    const base = new URL(app);
    const url = new URL(String(raw ?? ""), `${base.origin}/`);
    if (url.origin !== base.origin || !isAcceptableOrigin(url)) return null;
    return url.toString();
  } catch {
    return null;
  }
}

/** The engine URL the app says the tokens belong to, if it is safe to wire hooks to. */
export function acceptableApiUrl(raw) {
  if (typeof raw !== "string" || !raw.trim()) return null;
  try {
    const url = new URL(raw.trim());
    if (!isAcceptableOrigin(url)) return null;
    return url.toString().replace(/\/+$/, "");
  } catch {
    return null;
  }
}

/** True when nobody is at the keyboard to approve (CI, piped output). */
export function isUnattended({ env = process.env, stdoutIsTTY = Boolean(process.stdout.isTTY) } = {}) {
  return Boolean(env.CI) || !stdoutIsTTY;
}

/**
 * How to open a URL in the default browser here, or null when there is no
 * browser to open (CI, SSH, no display, opted out).
 */
export function browserCommand(url, { platform = osPlatform(), env = process.env } = {}) {
  if (env.VALORBRAIN_NO_BROWSER === "1" || env.CI) return null;
  // Over SSH the browser would open on the remote machine, not in front of the person.
  if (env.SSH_CONNECTION || env.SSH_TTY) return null;
  if (platform === "win32") return { cmd: "explorer.exe", args: [url] };
  if (platform === "darwin") return { cmd: "open", args: [url] };
  // WSL: the browser lives on the Windows side.
  if (env.WSL_DISTRO_NAME) return { cmd: "explorer.exe", args: [url] };
  if (!env.DISPLAY && !env.WAYLAND_DISPLAY) return null;
  return { cmd: "xdg-open", args: [url] };
}

/** Best effort: a browser that does not open is not an error, the URL is on screen. */
export function openBrowser(url, opts = {}) {
  const command = browserCommand(url, opts);
  if (!command) return false;
  try {
    const child = spawn(command.cmd, command.args, { stdio: "ignore", detached: true });
    child.on("error", () => {});
    child.unref();
    return true;
  } catch {
    return false;
  }
}

class LoginError extends Error {}

const sleepFor = (ms) => new Promise((r) => setTimeout(r, ms));

async function readJson(res) {
  try {
    return await res.json();
  } catch {
    return null;
  }
}

function withTimeout(init) {
  return { ...init, signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS) };
}

/**
 * Runs the whole login. Resolves with the tokens the app handed over:
 * `{ tokens: { <harness>: vbm_… } | null, accessToken, apiUrl, tenantId }`.
 * Rejects with a message meant for the person (denied, expired, app down).
 */
export async function deviceLogin({
  app,
  harnesses,
  label = deviceLabel(),
  install = null,
  browser = true,
  fetchImpl = fetch,
  sleep = sleepFor,
  now = Date.now,
  log = (line) => console.log(line),
  open = openBrowser,
  style = { bold: "", dim: "", off: "" },
}) {
  const headers = { "content-type": "application/json", accept: "application/json" };
  let res;
  try {
    res = await fetchImpl(`${app}/api/v1/cli/device/code`, withTimeout({
      method: "POST",
      headers,
      body: JSON.stringify({ client: "connect", harnesses, device_label: label, ...(install ? { install_id: install } : {}) }),
    }));
  } catch (err) {
    throw new LoginError(`Could not reach ${app} (${err?.message ?? err}). Check your connection and try again.`);
  }
  const code = (await readJson(res)) ?? {};
  if (!res.ok || !code.device_code || !code.user_code) {
    throw new LoginError(
      code.error_description || code.error
        ? `The app refused the login: ${code.error_description || code.error}`
        : `The app refused the login (HTTP ${res.status}).`,
    );
  }

  const offered = code.verification_uri_complete
    || (code.verification_uri ? `${code.verification_uri}?code=${encodeURIComponent(code.user_code)}` : null);
  const url = approvalUrl(offered, app) ?? approvalUrl(`/cli/link?code=${encodeURIComponent(code.user_code)}`, app);
  if (!url) throw new LoginError(`The app at ${app} did not give an approval page this installer can open.`);

  log("");
  log(`${style.bold}Approve this computer in your browser${style.off}`);
  log(`  ${url}`);
  log(`  code ${style.bold}${code.user_code}${style.off} ${style.dim}(check it matches the page)${style.off}`);
  const opening = browser ? open(url) : false;
  log(`${style.dim}${opening ? "Opening your browser… if it does not open, use the link above. " : "Open the link above. "}No account yet? You create it there. Waiting…${style.off}`);

  const deadline = now() + Math.max(60, Number(code.expires_in) || 900) * 1000;
  const baseInterval = Math.max(1, Number(code.interval) || 3) * 1000;
  let interval = baseInterval;
  while (now() < deadline) {
    await sleep(interval);
    let poll;
    try {
      poll = await fetchImpl(`${app}/api/v1/cli/device/token`, withTimeout({
        method: "POST",
        headers,
        body: JSON.stringify({ device_code: code.device_code }),
      }));
    } catch {
      continue; // network blip or timeout: the code is still valid, keep waiting
    }
    const body = await readJson(poll);
    if (poll.ok && body?.access_token) {
      const tokens = body.tokens && typeof body.tokens === "object" ? body.tokens : null;
      return {
        tokens,
        accessToken: body.access_token,
        apiUrl: acceptableApiUrl(body.valorbrain_url),
        tenantId: body.tenant_id ?? null,
      };
    }
    const error = body?.error;
    if (error === "authorization_pending") {
      interval = baseInterval;
      continue;
    }
    if (error === "slow_down") {
      interval += 5000;
      continue;
    }
    if (error === "access_denied") throw new LoginError("The request was denied in the browser. Nothing was changed.");
    if (error === "expired_token") throw new LoginError("The code expired before it was approved. Run the command again.");
    // The app restarting, a proxy error page, rate limiting: wait and ask again
    // until the code expires. Giving up here would strand an approval the
    // person may be completing right now.
    if (poll.status >= 500 || poll.status === 429 || body === null) {
      const retryAfter = Number(poll.headers?.get?.("retry-after"));
      interval = Math.min(30_000, Number.isFinite(retryAfter) && retryAfter > 0 ? retryAfter * 1000 : interval * 2);
      continue;
    }
    throw new LoginError(`Unexpected answer from the app (HTTP ${poll.status}${error ? `: ${error}` : ""}).`);
  }
  throw new LoginError("The code expired before it was approved. Run the command again.");
}
